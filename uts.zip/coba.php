<?php
// parent class
class Fruit {
  public $name;
  public $color;

  public function __construct($name, $color) {
    $this->name = $name;
    $this->color = $color; 
  }

  public function intro() {
    echo "The fruit is {$this->name} and the color is {$this->color}.\n"; 
  }
}   

// Strawberry is inherited from Fruit/child class
class Strawberry extends Fruit {
  public function message() {
    echo "Am I a fruit or a berry? \n"; 
  }

  // Overriding the intro method
  public function intro() {
    parent::intro(); // Call the parent class method
    echo "This is a strawberry, which is a type of fruit. The color is {$this->color}. \n";
  }
}

// child from child class
class Blueberry extends Strawberry {
  public function message() {
    echo "Am I a fruit or a berry? \n"; 
  }

  // Overriding the intro method
  public function intro() {
    parent::intro(); // Call the parent class method
    echo "This is a blueberry, which is also a type of fruit. The color is {$this->color}.\n";
  }
}

$strawberry = new Strawberry("Strawberry", "red");
$strawberry->message();
$strawberry->intro();

$blueberry = new Blueberry("Blueberry", "blue");
$blueberry->message();
$blueberry->intro();

trait message1 {
    public function msg1() {
      echo "YUMM YUMMM!!! "; 
    }
  }
  
  class Welcome {
    use message1;
  }
  
  $obj = new Welcome();
  $obj->msg1();

?>
