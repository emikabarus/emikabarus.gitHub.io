<?php

public class A{

    public int id {}
    public string title {}
    public string author {}
}